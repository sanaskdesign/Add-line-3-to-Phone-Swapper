document.getElementById('runBtn').addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0].id) {
        chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          func: () => {
            const addressField = document.querySelector('input[name="addContact_address3"]');
            const phoneField = document.querySelector('input[name="addContact_businessPhoneNumber"]');
  
            if (addressField && addressField.value.trim() !== '') {
              const valueToMove = addressField.value.trim();
              addressField.value = '';
              console.log('Moved value from addContact_address3:', valueToMove);
  
              if (phoneField) {
                phoneField.value = valueToMove;
                console.log('Inserted value into addContact_businessPhoneNumber.');
                alert('✅ Swapped successfully!');
              } else {
                alert('⚠️ Business phone field not found.');
              }
            } else {
              alert('⚠️ No value in Address Line 3 field.');
            }
          }
        });
      }
    });
  });
  